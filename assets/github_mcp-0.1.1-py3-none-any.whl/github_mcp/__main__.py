"""Start the GitHub MCP stdio server with host-owned credentials."""

import argparse
import asyncio
import logging
import math
import os
import subprocess
from contextlib import suppress

from . import __version__


def github_token() -> str:
    """Use the first nonempty environment credential, falling back to GitHub CLI login."""
    for name in ("GH_TOKEN", "GITHUB_TOKEN", "GITHUB_PERSONAL_ACCESS_TOKEN"):
        if value := os.environ.get(name, "").strip():
            return value
    try:
        result = subprocess.run(
            ["gh", "auth", "token", "--hostname", "github.com"],
            capture_output=True, text=True, check=False, timeout=10,
        )
    except (OSError, subprocess.TimeoutExpired):
        return ""
    return result.stdout.strip() if result.returncode == 0 else ""


def parser() -> argparse.ArgumentParser:
    cli = argparse.ArgumentParser(description="Serve one read-only GitHub tool over MCP stdio.")
    cli.add_argument("--version", action="version", version=f"github-mcp {__version__}")
    cli.add_argument("--backend", choices=("rest", "graphql", "dsl"), default="rest",
                     help="Backend exposed as the github tool (default: rest)")
    cli.add_argument("--concurrency", type=int, default=8, help="Concurrent HTTP requests (default: 8)")
    cli.add_argument("--timeout", type=float, default=60.0, help="HTTP I/O timeout in seconds (default: 60)")
    return cli


def main():
    cli = parser()
    args = cli.parse_args()
    if args.concurrency < 1 or not math.isfinite(args.timeout) or args.timeout <= 0:
        cli.error("--concurrency and --timeout must be positive finite numbers")
    logging.basicConfig(level=logging.WARNING)
    from .server import serve

    with suppress(KeyboardInterrupt):
        asyncio.run(serve(backend=args.backend, token=github_token(),
                          concurrency=args.concurrency, http_timeout=args.timeout))


if __name__ == "__main__":
    main()

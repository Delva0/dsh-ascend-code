"""Expose one backend's native GitHub tool contract through an MCP stdio server.

Each connection owns its HTTP client, saved responses and temporary files. The
tool registry keeps batch validation local to each item, including through MCP.
"""

import json
import math
from contextlib import asynccontextmanager
from pathlib import Path
from tempfile import TemporaryDirectory

import httpx
from jsonschema import ValidationError
from mcp import types
from mcp.server.lowlevel import Server
from mcp.server.stdio import stdio_server

from . import __version__
from .registry import ToolRegistry, input_error, installed_specs
from .storage import ToolStorage
from .tool_github import GitHubDSLTool, GitHubGraphQLTool, GitHubRESTTool

BACKENDS = {"rest": GitHubRESTTool, "graphql": GitHubGraphQLTool, "dsl": GitHubDSLTool}


def result(value: dict, *, failed: bool = False) -> types.CallToolResult:
    return types.CallToolResult(
        content=[types.TextContent(type="text", text=json.dumps(value, ensure_ascii=False))],
        structuredContent=value,
        isError=failed,
    )


def create_server(*, backend="rest", token="", concurrency=8, timeout=60.0, transport=None) -> Server:
    """Create a single-tool server without opening connections until its lifespan starts.

    Args:
        backend: Select REST, native GraphQL, or the combined GraphQL/REST DSL.
        token: GitHub credential; empty allows anonymous requests where supported.
        concurrency: Maximum simultaneous HTTP requests within the selected backend.
        timeout: HTTP timeout in seconds, applied independently to each I/O phase.
        transport: Optional HTTP transport for embedding and deterministic tests.
    """
    if backend not in BACKENDS:
        raise ValueError(f"Unknown backend: {backend}")
    if concurrency < 1 or not math.isfinite(timeout) or timeout <= 0:
        raise ValueError("concurrency and timeout must be positive")
    provider_type = BACKENDS[backend]
    _, spec = installed_specs(provider_type, "github")[0]

    @asynccontextmanager
    async def lifespan(server):
        with TemporaryDirectory(prefix="github-mcp-") as directory:
            async with httpx.AsyncClient(transport=transport, timeout=timeout, follow_redirects=False) as client:
                provider = provider_type(client, ToolStorage(Path(directory)), token=token, concurrency=concurrency)
                yield ToolRegistry((provider, "github"))

    server = Server("github-mcp", version=__version__, lifespan=lifespan)

    @server.list_tools()
    async def list_tools():
        return [types.Tool(
            name="github",
            description=spec.description,
            inputSchema=spec.parameters,
            outputSchema=spec.returns,
            annotations=types.ToolAnnotations(readOnlyHint=True, destructiveHint=False, openWorldHint=True),
        )]

    # Whole-input SDK validation would reject valid siblings of a malformed batch item.
    @server.call_tool(validate_input=False)
    async def call_tool(name, arguments):
        if name != "github":
            return result({"error": {"code": "unknown_tool", "message": f"Unknown tool: {name}"}}, failed=True)
        context = server.request_context
        registry = context.lifespan_context
        try:
            output = await registry.call("github", str(context.request_id), arguments)
        except (ValidationError, ValueError) as exc:
            return result({"error": input_error(exc)}, failed=True)
        items = output.get("results", [])
        failed = bool(output.get("errors") or output.get("error") or (items and all(r.get("error") for r in items)))
        return result(output, failed=failed)

    return server


async def serve(*, backend="rest", token="", concurrency=8, http_timeout=60.0):
    """Run the selected backend until the MCP client closes standard input.

    Args:
        backend: Backend whose schema and handler are published as ``github``.
        token: GitHub credential resolved by the CLI or embedding application.
        concurrency: Maximum simultaneous upstream HTTP requests.
        http_timeout: Timeout in seconds for each upstream HTTP I/O phase.
    """
    server = create_server(backend=backend, token=token, concurrency=concurrency, timeout=http_timeout)
    async with stdio_server() as streams:
        await server.run(*streams, server.create_initialization_options())

"""Standalone read-only GitHub tools served over MCP."""

__version__ = "0.1.1"
